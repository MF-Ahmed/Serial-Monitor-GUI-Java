#!/bin/sh

./autogen.sh

./configure
