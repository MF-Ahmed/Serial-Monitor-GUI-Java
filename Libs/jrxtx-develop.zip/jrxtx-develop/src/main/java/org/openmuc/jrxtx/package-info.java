/**
 * Packaged coating functionality for RxTx communication via java.
 */
package org.openmuc.jrxtx;
