package gnu.io;

public interface CommPortEnum {
    int value();
}
