@java.lang.Deprecated
package gnu.io;
